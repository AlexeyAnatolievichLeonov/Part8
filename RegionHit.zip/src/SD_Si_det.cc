#include "SD_Si_det.hh"
#include<G4OpticalPhoton.hh>

SD_Si_det :: SD_Si_det (G4String SDname) : G4VSensitiveDetector(SDname)
{
 G4String filename[10];
 char str[3];
 G4int i;
 for (i=0;i<10;i++)
 {
  filename[i] ="hit_Si_det_";
  sprintf(str,"%d",i+1);
  filename[i]+=str;
  filename[i]+=".dat";
//  G4cout<<filename[i]<<" "<<G4endl;
  hit_SD_Si_det[i].open(filename[i],std::fstream::out);
 }
 for (i=0; i<10; i++) {SumE[i]=0.;}
}

SD_Si_det :: ~SD_Si_det()
{
 for (G4int i=0; i<10; i++) {hit_SD_Si_det[i].close();}
}

extern G4int eventID;

void SD_Si_det :: EndOfEvent(G4HCofThisEvent*)
{
 for (G4int i=0; i<10; i++)
 {hit_SD_Si_det[i] << std::setw(10) << SumE[i] << std::setw(10) << this->GetCopyNum(i+1) << G4endl;}
 for (G4int i=0; i<10; i++)
 {SumE[i]=0.; CopyNum[i]=0;}
}

G4bool SD_Si_det :: ProcessHits(G4Step* step, G4TouchableHistory*)
{
 G4TouchableHandle touchable = step->GetPreStepPoint()->GetTouchableHandle();
 G4int copyNo     = touchable->GetVolume(0)->GetCopyNo();
 G4String LogName = touchable->GetVolume(0)->GetLogicalVolume()->GetName();

 G4double edep  = 0.;
 edep           = step->GetTotalEnergyDeposit();
 if (strcmp(LogName,"Si_det_vol_log")==0)
 {
  this->SetCopyNum(copyNo);
  this->AddSumE(edep,copyNo);
 }
 return true;
}

