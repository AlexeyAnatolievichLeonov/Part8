#include "G4UnitsTable.hh"
#include "G4VVisManager.hh"
#include "G4Circle.hh"
#include "G4Color.hh"
#include "G4VisAttributes.hh"

#include "SD_Si_det_hit.hh"

G4Allocator<SD_Si_det_hit> hitAllocatorSD;

SD_Si_det_hit::SD_Si_det_hit() : eDep_hit(0) {}
SD_Si_det_hit::~SD_Si_det_hit(){}

SD_Si_det_hit::SD_Si_det_hit(const SD_Si_det_hit& right):G4VHit()
{
 eDep_hit        = right.eDep_hit;
 layerNumber_hit = right.layerNumber_hit;
}

const SD_Si_det_hit& SD_Si_det_hit::operator=(const SD_Si_det_hit& right)
{
 eDep_hit        = right.eDep_hit;
 layerNumber_hit = right.layerNumber_hit;
 return *this;
}

G4int SD_Si_det_hit::operator==(const SD_Si_det_hit& right) const
{
 return (this==&right) ? 1 : 0;
}

void SD_Si_det_hit::Draw()
{
}

void SD_Si_det_hit::Print()
{
 G4cout      << "eDep: "        << eDep_hit << G4endl;
 G4cout      << "layerNumber: " << layerNumber_hit << G4endl;
}


