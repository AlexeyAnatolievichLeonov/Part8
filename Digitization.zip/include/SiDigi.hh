#ifndef SiDigitizer_h
#define SiDigitizer_h 1

#include <G4VDigi.hh>
#include "G4TDigiCollection.hh"
#include "G4Allocator.hh"
#include "G4ThreeVector.hh"

class SiDigi : public G4VDigi
{
 public:
  explicit SiDigi();
  ~SiDigi();

  SiDigi(const SiDigi&);
  const SiDigi& operator=(const SiDigi&);
  G4int operator==(const SiDigi&) const;
  
  inline void* operator new(size_t);
  inline void  operator delete(void *aDig);

  void Draw();  
  void Print();
  
  void SetEdep(const double e) {this->eDep_digi=e;}
  G4double GetEdep() const {return eDep_digi;}

  void SetLayerNumber(const int c) {this->layerNumber_digi=c;}  
  G4int GetLayerNumber() const {return layerNumber_digi;}
  
 private:
  G4int layerNumber_digi;
  G4double eDep_digi;
};

typedef G4TDigiCollection<SiDigi> SiDigi_Collection;

extern G4Allocator<SiDigi> DigiAllocator;

inline void* SiDigi::operator new(size_t)
{
 void* aDigi;
 aDigi = (void*) DigiAllocator.MallocSingle();
 return aDigi;
}

inline void SiDigi::operator delete(void* aDigi)
{
 DigiAllocator.FreeSingle((SiDigi*) aDigi);
}

#endif
