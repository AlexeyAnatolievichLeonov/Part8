#ifndef SiDigitizer_HH
#define SiDigitizer_HH

#include <G4Material.hh>
#include "G4NistManager.hh"

#include "G4VDigitizerModule.hh"
#include "G4DigiManager.hh"
#include "G4Step.hh"
#include "G4HCofThisEvent.hh"
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdio.h>

#include "SiDigi.hh"
#include "SD_Si_det.hh"

class SiDigitizer : public G4VDigitizerModule
{
 public:
  SiDigitizer(G4String SDname);
  ~SiDigitizer();

  void Digitize();

 private:
 SiDigi_Collection* digCollection;
};

#endif

