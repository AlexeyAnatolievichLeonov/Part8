#include "SiDigi.hh"
#include "SiDigitizer.hh"

SiDigitizer :: SiDigitizer (G4String SDname) : G4VDigitizerModule(SDname) 
{
 collectionName.push_back("digCollection");
}

SiDigitizer :: ~SiDigitizer() {}

void SiDigitizer :: Digitize()
{
 digCollection = new SiDigi_Collection("SiDigitizer", "digCollection");
 G4DigiManager* digitManager = G4DigiManager::GetDMpointer();
 G4int collectionID=digitManager->GetHitsCollectionID("SD_Si_det_hitCollection");
 SD_Si_det_hitCollection* hitCollection{nullptr};
 hitCollection=(SD_Si_det_hitCollection*)(digitManager->GetHitsCollection(collectionID));

 G4int i;
 if (hitCollection!=nullptr)
 {
  G4int numberOfHits=hitCollection->entries();
  for (i=0; i<numberOfHits; i++)
  {
   G4double depositedEnergy=(*hitCollection)[i]->GetEdep();
   depositedEnergy=(int)(depositedEnergy*10.);
   G4int ln=(*hitCollection)[i]->GetLayerNumber();
   SiDigi* digit=new SiDigi();
   digit->SetEdep(depositedEnergy);
   digit->SetLayerNumber(ln);
   digCollection->insert(digit);
  }
 }
 StoreDigiCollection(digCollection);
}

