#include "G4UnitsTable.hh"
#include "G4VVisManager.hh"
#include "G4Circle.hh"
#include "G4Color.hh"
#include "G4VisAttributes.hh"

#include "SiDigi.hh"

G4Allocator<SiDigi> DigiAllocator;

SiDigi::SiDigi() : eDep_digi(0) {}
SiDigi::~SiDigi(){}

SiDigi::SiDigi(const SiDigi& right):G4VDigi()
{
 eDep_digi       = right.eDep_digi;
 layerNumber_digi= right.layerNumber_digi;
}

const SiDigi& SiDigi::operator=(const SiDigi& right)
{
 eDep_digi       = right.eDep_digi;
 layerNumber_digi= right.layerNumber_digi;
 return *this;
}

G4int SiDigi::operator==(const SiDigi& right) const
{
 return (this==&right) ? 1 : 0;
}

void SiDigi::Draw()
{
}

void SiDigi::Print()
{
 G4cout      << "eDep: "        << eDep_digi << G4endl;
 G4cout      << "layerNumber: " << layerNumber_digi << G4endl;
}


